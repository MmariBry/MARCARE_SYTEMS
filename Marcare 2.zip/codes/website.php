<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<!--This cam be veiwed in the HTML part of a document-->
<a href="http://www.domain.com/">Visit Our Site</a>
<b>Example</b>
<big>Example</big>
<body>The content of your HTML page</body>
The content of your page<br>The content of your page
<center>This will your page your content</center>
<dl>
<dt>Definition Term</dt>
<dd>Definition of the term</dd>
<dt>Definition Term</dt>
<dd>Definition of the term</dd>
</dl>
<dl>
<dt>Definition Term</dt>
<dd>Definition of the term</dd>
<dt>Definition Term</dt>
<dd>Definition of the term</dd>
</dl>
<dl>
<dt>Definition Term</dt>
<dd>Definition of the term</dd>
<dt>Definition Term</dt>
<dd>Definition of the term</dd>
</dl>
This is an <em>Example</em> of using the emphasis tag
<embed src="yourfile.mid"width="100%"height="60" align="center">
<embed src="yourfile.mid" autostart="true" hidden="false" loop="false"><noembed><bgsound src="yourfile.mid" loop="1"></noembed>
<font face="Times New Roman">Example</font>
<font face="Times New Roman" size="4">Example</font>
<font face="Times New Roman" size="+3" color="#ff0000">Example</font>
<form "> action="mailto:you@yourdomain.com
Name: <input name="Name" value=""
size="10"><br>
Email: <input name="Email" value=""
size="10"><br>
<center><input type="submit"></center>
</form>
<h1>Heading 1 Example</h1>
<h2>Heading 2 Example</h2>
<h3>Heading 3 Example</h3>
<h4>Heading 4 Example</h4>
<h5>Heading 5 Example</h5>
<h6>Heading 6 Example</h6>
<head>Contains elements describing the document</head>
<hr/>
<hr width =^ prime prime 50% ^ prime prime size="3" />
<hr width =^ prime prime 50% ^ prime prime size="3" noshade />
<hr width =^ prime prime (75%)% color="#ff0000" size =^ prime prime 4 ^ prime prime />
<hr width =^ prime prime 25% color="#6699ff" size =^ prime prime 6 ^ prime prime />
<html>
<head>
<meta>
<title>Title of your web page</title>
</head>
<body>HTML web page contents
</body>
</html>
<i>Example</i>
<img src="Earth.gif" width =^ x 41^ prime prime
height="41" border =^ prime prime 0 ^ prime prime alt="text describing
the image" />
Example 1:
<form method-post action="/cgi-
bin/example.cgi">
<input type="text" size="10"
maxlength="30">
<input type="Submit" value="Submit">
</form>
Example 2:
<form method=post action="/cgi-
bin/example.cgl">
<input type="text" style="color: #ffffff; font-family: Verdana; font-weight: bold; font- size: 12px; background-color: #72a4d2;" size="10" maxlength="30">
<input type="Submit" value="Submit">
</form>
Example 3:
<form method=post action="/cgi-
bin/example.cgi">
<table border="0" cellspacing="0"
cellpadding="2"><tr><td
bgcolor="#8463ff"><input type="text" 
size="10" maxlength="30"></td><td 
bgcolor="#8463ft" valign="middle"> 
<input type="image" name="submit" 
="yourimage.gif"></td></tr> </table>
Example 4:
<form method=post action="/cgl-
bin/example.cgl">
Enter Your Comments:<br>
<textarea wrap="virtual" name="Comments" rows 3 cols=20
maxlength=100></textarea><br>
<input type="Submit" value="Submit">
<input type="Reset" value="Clear">
</form>
Example 5:
<form method=post action="/cgi-
bin/example.cgl">
<center>
Select an option:
<select>
<option>option 1</option>
<option selected>option 2</option>
<option>option 3</option>
<option>option 4</option>
<option>option 5</option>
<option>option 6</option>
</select><br>
<input type="Submit"
value="Submit"></center>
</form>
Example 6:
<form method=post action="/cgi-
bin/example.cg/">
Select an option:<br>
<input type="radio" name="option">Option1
<input type="radio" name="option"checked > Option 2
<input type="radio" name="option"> Option3
<br>
<br>
Select an option: <br>
<input type="checkbox" name="selection">Selection 1
<input type="checkbox" name="selection"checked> Selection 2
<input type="checkbox"
name="selection"> Selection 3
<input type="Submit" value="Submit"></form>
Example 1:
<<menu>
<li type="disc">List item 1</li>
<li type="circle">List item 2</li>
<li type="square">List item 3</li>
<</MENU>
Example 2:
<ol type="i">
<li>List item 1</li>
<li>List item 2</li>
<li>Liat item 3</li>
<li>List item 4</li>
</ol>
<head>
<link rel="stylesheet"type="text/css"
href="style.css" />
</head>
<marquee bgcolor="#ccccc" loop="-1"
scrollamount="2" width="100%">Example
Marquee</marquee>
<menu>
<li type="disc">List item 1</li>
<li type="circle">List item 2</li>
<li type="square">List item 3</li>
</menu>
<meta name="Description"
content="Description of your site">
<meta name="keywords"
content="keywords description your site"
<meta HTTP-EQUIV="Refresh"
CONTENT="4;URL=http://www.yourdomain.com/">
<meta http-equiv="Pragma" content="no- cache">
<meta name="rating" content="General">
<meta name="robots" content="all">
<meta name="robots"
content="noindex, follow">
Numbered
<ol>
<li>List item 1</li>
<li>List item 2</II>
<li>List item 3</li>
<li>List item 4</li>
</ol>
Numbered Special Start
<ol start="5">
<li>List item 1</li>