<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <!-- NavBar -->
        <div class="row mb-5">
            <div class="col-8 offset-2 fixed-top w-dz mx-auto border border-top-0 px-0 shadow">
                <nav class="navbar navbar-expand-lg bg-body-tertiary" data-be-theme="light">
                    <div class="container-fluid">
                        <a href="#" class="navbar-brand">Marcare</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a href="./Patients/Register_patient.php" class="nav-link active" aria-current="page">Reception</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#accordionExample" class="nav-link">Accounts</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        Departments
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#cards">Doctor (MD)</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li> 
                                        <li><a class="dropdown-item" href="#carouselExampleDark">Lab</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>   
                                        <li><a class="dropdown-item" href="#collapse">Pharmacy</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link disabled" aria-disabled="true">Wards</a>
                                </li>    
                            </ul>
                            <form class="d-flex" role="search">
                                <input type="search" placeholder="Search" class="form-control me-2" aria-label="Search">
                                <btton class="btn btn-outline-success" type="search">Search</btton>
                            </form>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

        <!-- Bootstrap JavaScript -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUJheZkLFASBK+mmO/I/YPECEsjCZXvYWHAJw71nIk=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXlK27kzH3eG7h7e8M4e0bxtdB1onWIRVj38Gh5iZG7yHstk4j+4pH6fGSI" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-M5viidIK25agsTR7QnjWaFyk4w7ZmZbajBmt3oz/maotlkfJbcOx2MHxCT6mBnbH" crossorigin="anonymous"></script>
    </div>
</body>
<style>
.text-justify{
    text-align: justify;
}
.w-dz{
    max-width: 54.5%;
}
</style>
</html>
