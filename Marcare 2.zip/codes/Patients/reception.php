<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Marcare Reception</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <!-- NavBar -->
        <div class="row mb-5">
            <div class="fixed-top w-dz mx-auto border border-top-0 px-0 shadow">
                <nav class="navbar navbar-expand-lg bg-body-tertiary" data-be-theme="light">
                    <div class="container-fluid">
                        <a href="#" class="navbar-brand">Marcare</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a href="#" class="nav-link active" aria-current="page">Register</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#accordionExample" class="nav-link">Accounts</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle- disabled" role="button" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        Departments
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#cards">Doctor (MD)</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li> 
                                        <li><a class="dropdown-item" href="#carouselExampleDark">Lab</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>   
                                        <li><a class="dropdown-item" href="#collapse">Pharmacy</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link disabled" aria-disabled="true">Wards</a>
                                </li>    
                            </ul>
                            <!-- <form class="d-flex" role="search">
                                <input type="search" placeholder="Search" class="form-control me-2" aria-label="Search">
                                <btton class="btn btn-outline-success" type="search">Search</btton>
                            </form> -->
                            <!-- search_patient.php -->
                            <form class="d-flex" method="POST" action="check_patients.php">
                                <input type="search" id="patient_id" name="patient_id" placeholder="Enter Patient ID or Name"class="form-control me-2" aria-label="Search" required>
                                <button class="btn btn-outline-success" type="submit" name="search">Search</button>
                            </form>


                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>  
<!-- Welcome Section -->
<div class="container my-4">
  <h1 class="text-center">Welcome to Our Healthcare System</h1>
  <p class="text-center">We are committed to providing you with the best care and service. Below are resources to help you during your visit.</p>
</div>

<!-- Contact Information Section -->
<div class="container my-4">
  <h2>Contact Information</h2>
  <ul class="list-group">
    <li class="list-group-item"><strong>Emergency Contacts:</strong> +123-456-7890</li>
    <li class="list-group-item"><strong>Main Reception:</strong> +123-456-7891</li>
    <li class="list-group-item"><strong>Billing Department:</strong> +123-456-7892</li>
    <li class="list-group-item"><strong>Appointments:</strong> +123-456-7893</li>
  </ul>
</div>

<!-- Facility Map Section -->
<div class="container my-4">
  <h2>Facility Map</h2>
  <img src="map-placeholder.jpg" alt="Facility Map" class="img-fluid">
  <p>Find key locations like the reception, pharmacy, and clinics on this map. For help, feel free to ask our staff.</p>
</div>

<!-- Patient Information Section -->
<div class="container my-4">
  <h2>Patient Information</h2>
  <div class="accordion" id="patientInfoAccordion">
    <div class="accordion-item">
      <h2 class="accordion-header" id="rightsHeading">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#rightsCollapse" aria-expanded="false" aria-controls="rightsCollapse">
          Patient Rights & Responsibilities
        </button>
      </h2>
      <div id="rightsCollapse" class="accordion-collapse collapse" aria-labelledby="rightsHeading" data-bs-parent="#patientInfoAccordion">
        <div class="accordion-body">
          <p>As a patient, you have the right to quality care, privacy, and respect. You also have responsibilities, such as providing accurate information and following prescribed treatments.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="privacyHeading">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#privacyCollapse" aria-expanded="false" aria-controls="privacyCollapse">
          Privacy and Confidentiality
        </button>
      </h2>
      <div id="privacyCollapse" class="accordion-collapse collapse" aria-labelledby="privacyHeading" data-bs-parent="#patientInfoAccordion">
        <div class="accordion-body">
          <p>Your personal data is protected in accordance with our privacy policies. We ensure that your information is kept secure and used only for your treatment and care.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Services Overview Section -->
<div class="container my-4">
  <h2>Services Overview</h2>
  <ul class="list-group">
    <li class="list-group-item">General Medical Services</li>
    <li class="list-group-item">Specialist Consultations</li>
    <li class="list-group-item">Radiology and Imaging</li>
    <li class="list-group-item">Laboratory Tests</li>
    <li class="list-group-item">Pharmacy Services</li>
  </ul>
</div>

<!-- Digital Tools Section -->
<div class="container my-4">
  <h2>Digital Tools</h2>
  <ul class="list-group">
    <li class="list-group-item">Download our mobile app to manage appointments and access your health records.</li>
    <li class="list-group-item">Access our <a href="#">Online Patient Portal</a> for bills, reports, and appointments.</li>
    <li class="list-group-item">Free Wi-Fi is available in the facility. Connect to <strong>Healthcare-WiFi</strong> (password: care123).</li>
  </ul>
</div>

<!-- Health and Safety Information Section -->
<div class="container my-4">
  <h2>Health and Safety Information</h2>
  <ul class="list-group">
    <li class="list-group-item">Please maintain hand hygiene by using the sanitizers placed throughout the facility.</li>
    <li class="list-group-item">Wear masks in all patient areas.</li>
    <li class="list-group-item">In case of emergency, follow the evacuation route posted on the maps around the building.</li>
  </ul>
</div>

<!-- Feedback and Complaints Section -->
<div class="container my-4">
  <h2>Feedback and Complaints</h2>
  <form>
    <div class="mb-3">
      <label for="name" class="form-label">Your Name</label>
      <input type="text" class="form-control" id="name" placeholder="Enter your name">
    </div>
    <div class="mb-3">
      <label for="email" class="form-label">Your Email</label>
      <input type="email" class="form-control" id="email" placeholder="Enter your email">
    </div>
    <div class="mb-3">
      <label for="message" class="form-label">Message</label>
      <textarea class="form-control" id="message" rows="3" placeholder="Share your feedback or concerns"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Send Feedback</button>
  </form>
</div>

<!-- Entertainment & Comfort Section -->
<div class="container my-4">
  <h2>Entertainment & Comfort</h2>
  <ul class="list-group">
    <li class="list-group-item">Enjoy TV in the waiting areas. Channels include news, health documentaries, and kids' shows.</li>
    <li class="list-group-item">Refreshments are available at our cafeteria, located on the ground floor.</li>
    <li class="list-group-item">Family-friendly play areas are available for children in waiting zones.</li>
  </ul>
</div>

<!-- Personalized Information Section -->
<div class="container my-4">
  <h2>Your Appointment Details</h2>
  <ul class="list-group">
    <li class="list-group-item"><strong>Date:</strong> October 12, 2024</li>
    <li class="list-group-item"><strong>Time:</strong> 10:30 AM</li>
    <li class="list-group-item"><strong>Doctor:</strong> Dr. Jane Smith (Cardiology)</li>
  </ul>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
