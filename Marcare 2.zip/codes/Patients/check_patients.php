<!-- check_patient.php -->
<?php
require 'db_connect.php';  // File where DB connection is established

if(isset($_POST['search'])){
    // Get the patient ID from the form submission
    $patient_id = $_POST['patient_id'];

    // Check if the patient exists in the database
    $sql = "SELECT * FROM patients WHERE patient_id = '$patient_id' OR name = '$patient_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // If patient exists, load the edit form
        $patient = $result->fetch_assoc();
        include 'edit_patient.php';
    } else {
        // If patient does not exist, load the registration form
        include 'register_patient.php';
    }
}





?>