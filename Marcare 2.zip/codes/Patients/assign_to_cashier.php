<!-- assign_to_cashier.php -->
<?php
require 'db_connect.php';

$patient_id = $_GET['patient_id'];

// Set payment status to 'Pending'
$sql = "UPDATE patients SET payment_status='Pending' WHERE patient_id='$patient_id'";

if ($conn->query($sql) === TRUE) {
    echo "Patient assigned to cashier. Payment status: Pending.";
    header('Location: process_payment.php?patient_id=' . $patient_id);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
