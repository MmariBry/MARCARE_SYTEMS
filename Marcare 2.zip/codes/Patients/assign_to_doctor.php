<!-- assign_to_doctor.php -->
<?php
require 'db_connect.php';

$patient_id = $_GET['patient_id'];

// Check if the patient has paid
$sql = "SELECT payment_status FROM patients WHERE patient_id='$patient_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $patient = $result->fetch_assoc();
    if ($patient['payment_status'] == 'Paid') {
        echo "Patient can now visit the doctor.";
        // Here you can assign the patient to a doctor
    } else {
        echo "Payment not complete. Please go back to cashier.";
    }
} else {
    echo "Patient not found.";
}
?>
