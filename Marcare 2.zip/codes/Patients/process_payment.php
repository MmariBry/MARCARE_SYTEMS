<!-- process_payment.php -->
<?php
require 'db_connect.php';

$patient_id = $_GET['patient_id'];

// Mark payment as "Paid"
$sql = "UPDATE patients SET payment_status='Paid' WHERE patient_id='$patient_id'";

if ($conn->query($sql) === TRUE) {
    echo "Payment completed. Patient can now visit the doctor.";
    header('Location: assign_to_doctor.php?patient_id=' . $patient_id);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
