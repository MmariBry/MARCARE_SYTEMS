<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Patients</title>
    <link rel="stylesheet" href="../resources/bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12 col-md-8 offset-md-2 col-lg-6 offset-lg-3 p-4 border border-2 rounded-2">
                <form action="save_patient.php" method="post">
                    <!-- Register Heading -->
                    <div class="row">
                        <div class="col-12 mb-3">
                            <h2 class="text-center text-primary">REGISTER PATIENT</h2>
                        </div>
                     </div>
                    <!-- First Name & Last Name -->
                     <div class="row">
                        <div class="col-12 col-md-6 mb-3">
                            <label for="firstName" class="form-label">First Name:</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <label for="lastName" class="form-label">Last Name:</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required>
                        </div>
                     </div>
                     <!-- Age -->
                      <div class="row">
                        <div class="col-12 col-md-6 mb-3">
                            <label for="age" class="form-label">Age:</label>
                            <input type="number" class="form-control" id="age" name="age" min="1" max="150" required>
                        </div>
                        <!-- Gender -->
                        <div class="col-12 col-md-6">
                                <div class="row mb-3">
                                    <label for="gender" class="form-label">Gender</label>
                                    <div class="col-md-8 input-group">
                                        <select name="gender" id="gender" class="form-control">
                                            <option value="" disabled selected>---Select Gender---</option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <!-- phone number -->
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number:</label>
                            <div class="input-group">
                                <select class="form-select" id="countryCode" name="countryCode">
                                    <option value="+255">+255 (TZ)</option>    
                                    <option value="+254">+254 (KE)</option>
                                    <option value="+256">+256 (UG)</option>
                                </select>
                                <input type="tel" class="col-md-8 form-control" id="phone" name="phone" required>
                            </div>

                        </div>   
                         <!--Address  -->
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" list="add" id="address" name="address" class="form-control">
                            <datalist id="add">
                                <option value="Arusha"></option>
                                <option value="Kilimanjaro"></option>
                                <option value="Manyara"></option>
                                <option value="Dodoma"></option>
                                <option value="Tanga"></option>
                                <option value="Pwani"></option>
                                <option value="Dar-es-Salaam"></option>
                                <option value="Morogoro"></option>
                                <option value="Lindi"></option>
                                <option value="Mtwara"></option>
                            </datalist>
                        </div>
                        <!-- Submit & Reset -->
                        <div class="row">
                            <div class="col-12 col-md-6 mb-3">
                                <input type="submit" value="Register" class="btn btn-primary btn-block">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <input type="reset" value="Reset" class="btn btn-secondary btn-block">
                            </div>
                        </div>
                    <!-- Validation Errors -->
                     <!-- <div class="row">
                         <div class="col-12 col-md-6 offset-md-3 text-center">
                             <?php if(isset($_SESSION['error'])) { echo $_SESSION['error']; unset($_SESSION['error']); }?>
                         </div>
                     </div> -->
                     <!-- login if have account -->
                      <div class="row">
                            <div class="col-12 col-md-6 mt-3">
                                <a href="../dashboard.php" class="btn btn-outline-primary btn-block">Back</a>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <a href="../dashboard.php" class="btn btn-outline-success btn-block">Next</a>
                            </div>
                      </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

</body>
</html>