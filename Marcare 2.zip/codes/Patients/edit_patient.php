<!-- edit_patient.php -->
<form method="POST" action="update_patient.php">
    <input type="hidden" name="patient_id" value="<?= $patient['patient_id'] ?>">
    <div>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?= $patient['name'] ?>" required>
    </div>
    <div>
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" value="<?= $patient['age'] ?>" required>
    </div>
    <!-- Add other fields like gender, contact info, etc. -->
    <button type="submit">Update Patient</button>
</form>
