<!-- db_connect.php -->
<?php
$servername = "localhost";  // Usually localhost if your database is on the same server
$username = "root";  // Replace with your MySQL username
$password = "";  // Replace with your MySQL password
$dbname = "marcare";  // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
