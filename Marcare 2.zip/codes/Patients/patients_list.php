<!-- patients_list.php -->
<?php
require 'db_connect.php';

// Fetch patients with any payment status
$sql = "SELECT * FROM patients";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>S/No.</th>
                <th>Patient First Name</th>
                <th>Patient Last Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Phone Number</th>
                <th>Address</th>
                <th>Payment Status</th>
                <th>Action</th>
            </tr>";

    $serial_number = 1;

    // Loop through the patients and create a row for each one
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$serial_number}</td>
                <td>{$row['first_name']}</td>
                <td>{$row['last_name']}</td>
                <td>{$row['age']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['phone_number']}</td>
                <td>{$row['address']}</td>
                <td>{$row['payment_status']}</td>
                <td><a href='process_payment.php?patient_id={$row['patient_id']}'>Pay</a></td>
              </tr>";

        $serial_number++;
    }
    echo "</table>";
} else {
    echo "No patients found.";
}

$conn->close();
?>
