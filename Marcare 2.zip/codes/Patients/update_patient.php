<!-- update_patient.php -->
<?php
require 'db_connect.php';

$patient_id = $_POST['patient_id'];
$name = $_POST['name'];
$age = $_POST['age'];
// Add other fields as necessary

$sql = "UPDATE patients SET name='$name', age='$age' WHERE patient_id='$patient_id'";

if ($conn->query($sql) === TRUE) {
    echo "Patient details updated successfully.";
    header('Location: assign_to_cashier.php?patient_id=' . $patient_id);
} else {
    echo "Error updating record: " . $conn->error;
}
?>
