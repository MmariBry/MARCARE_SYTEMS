<!-- save_patient.php -->
<?php
require 'db_connect.php';

$first_name = $_POST['firstName'];
$last_name = $_POST['lastName'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$coutry_code = $_POST['countryCode'];
$phone = $_POST['phone'];
$phone_number = $coutry_code . ' ' . $phone;
$address = $_POST['address'];
// Add other fields as necessary

$sql = "INSERT INTO patients (first_name, last_name, age, gender, phone_number, address) VALUES ('$first_name', '$last_name', '$age', '$gender', '$phone_number', '$address')";

if ($conn->query($sql) === TRUE) {
    echo "New patient registered successfully.";
    header('Location: patients_list.php?patient_id=' . $conn->insert_id);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
